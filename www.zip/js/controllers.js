angular.module('starter.controllers', [])

.controller('MainController', function($scope, $http) {
    $scope.filter = {
        'cnpj': {'label': 'cnpj', 'value': false},
        'razaosocial': {'label': 'razaosocial', 'value': false},
        'nomefantasia': {'label': 'nomefantasia', 'value': false},
        'cidade': {'label': 'cidade', 'value': false},
        'bairro': {'label': 'bairro', 'value': false},
        'porteempregados': {'label': 'porteempregados', 'value': false},
        'setoratividade': {'label': 'setoratividade', 'value': false},
        'produtos': {'label': 'produtos', 'value': false},
        'industria': {'label': 'industria', 'value': false},
    }

    $scope.cidades = [];
    
    var loadCidades = function(){
      $http.get('cidades.json').success(function (res){
          $scope.cidades = res.cidades; 
      });
    }

    loadCidades();
})

.controller('FormController', function($scope, $http) {

    $scope.porte = [
      'Micro - 0 a 19 Empregados',
      'Pequena - 20 a 59 Empregados',
      'Média - 100 a 499 Empregados',
      'Grande - 500 Empregados'
    ];
    $scope.ind = [
      'Indústrias Exportadoras',
      'Indústrias não Exportadoras'
    ];

    $scope.consulta = {
      'cnpj': '',
      'razaosocial': '',
      'nomefantasia': '',
      'cidade': '',
      'porteempregados': '',
      'setoratividade': '',
      'produto': '',
      'industria': '',
    }

    $scope.consultar = function (consulta){
      console.log(consulta);
    }

});